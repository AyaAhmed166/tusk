package compiler;

public interface Record {
    public String toObjectProgram();
}