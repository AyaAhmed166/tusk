/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compiler;

/**
 *
 * @author user7
 */
class Tag {
    public final static int PROGRAM = 1;
    public final static int VAR = 2;
    public final static int BEGIN = 3;
    public final static int END = 4;
    public final static int END2 = 5;
    public final static int FOR = 6;
    public final static int READ = 7;
    public final static int WRITE = 8;
    public final static int TO = 9;
    public final static int DO = 10;
    public final static int SC = 11;
    public final static int ASSIGN = 12;
    public final static int PLUS = 13;
    public final static int IF = 14;
    public final static int LB = 15;
    public final static int RB = 16;
    public final static int ID = 17;
    public final static int ASTR = 18;  
    public final static int imm = 19;
    public final static int comma = 20;
    
    
    
    
}
