The program must have an input file entitled "input.txt" which is in the following format:

[number of rows of 1st matrix] [number of columns of 1st matrix]
1st matrix entries
[number of rows of 2nd matrix] [number of columns of 2nd matrix]
2nd matrix entries

Note: [] for clarity

ex:
3 5
1 -2 3 4 5
1 2 -3 4 5
-1 2 3 4 5
5 4
-1 2 3 4
1 -2 3 4
1 2 -3 4
1 2 3 -4
-1 -2 -3 -4

Then run the program normally and there will an output file entitled "output.txt" which is in the following format:

result matrix entries
END1	[elapsed time of procedure 1]
result matrix entries
END2	[elapsed time of procedure 2]